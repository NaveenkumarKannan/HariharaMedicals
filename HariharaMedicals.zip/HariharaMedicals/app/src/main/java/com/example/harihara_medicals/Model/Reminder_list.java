package com.example.harihara_medicals.Model;

public class Reminder_list {
    private   String reminderid,doctor_appointment,doctor_time,medicien,medicien_time,visit_medical,
            visit_time, remdate, remdesc;

    public String getReminderid() {
        return reminderid;
    }

    public void setReminderid(String reminderid) {
        this.reminderid = reminderid;
    }

    public String getDoctor_appointment() {
        return doctor_appointment;
    }

    public void setDoctor_appointment(String doctor_appointment) {
        this.doctor_appointment = doctor_appointment;
    }

    public String getDoctor_time() {
        return doctor_time;
    }

    public void setDoctor_time(String doctor_time) {
        this.doctor_time = doctor_time;
    }

    public String getMedicien() {
        return medicien;
    }

    public void setMedicien(String medicien) {
        this.medicien = medicien;
    }

    public String getMedicien_time() {
        return medicien_time;
    }

    public void setMedicien_time(String medicien_time) {
        this.medicien_time = medicien_time;
    }

    public String getVisit_medical() {
        return visit_medical;
    }

    public void setVisit_medical(String visit_medical) {
        this.visit_medical = visit_medical;
    }

    public String getVisit_time() {
        return visit_time;
    }

    public void setVisit_time(String visit_time) {
        this.visit_time = visit_time;
    }

    public String getRemdate() {
        return remdate;
    }

    public void setRemdate(String remdate) {
        this.remdate = remdate;
    }

    public String getRemdesc() {
        return remdesc;
    }

    public void setRemdesc(String remdesc) {
        this.remdesc = remdesc;
    }
}
