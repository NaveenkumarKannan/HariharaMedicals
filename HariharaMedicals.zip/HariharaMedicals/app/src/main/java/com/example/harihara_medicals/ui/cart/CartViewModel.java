package com.example.harihara_medicals.ui.cart;

import androidx.lifecycle.ViewModel;

public class CartViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
