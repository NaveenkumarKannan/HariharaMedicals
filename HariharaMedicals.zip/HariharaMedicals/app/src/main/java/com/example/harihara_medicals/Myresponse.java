package com.example.harihara_medicals;

public class Myresponse {
    boolean error;
    String message;
}
