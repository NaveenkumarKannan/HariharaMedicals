package com.example.harihara_medicals.ui.user;

import androidx.lifecycle.ViewModel;

public class UserViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
