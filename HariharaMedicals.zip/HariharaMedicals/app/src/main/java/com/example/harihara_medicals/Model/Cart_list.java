package com.example.harihara_medicals.Model;

public class Cart_list {
    String cart_tab_name,cart_tab_count,cart_tab_price,cart_id;

    public String getCart_tab_name() {
        return cart_tab_name;
    }

    public void setCart_tab_name(String cart_tab_name) {
        this.cart_tab_name = cart_tab_name;
    }

    public String getCart_tab_count() {
        return cart_tab_count;
    }

    public void setCart_tab_count(String cart_tab_count) {
        this.cart_tab_count = cart_tab_count;
    }

    public String getCart_tab_price() {
        return cart_tab_price;
    }

    public void setCart_tab_price(String cart_tab_price) {
        this.cart_tab_price = cart_tab_price;
    }

    public String getCart_id() {
        return cart_id;
    }

    public void setCart_id(String cart_id) {
        this.cart_id = cart_id;
    }
}
