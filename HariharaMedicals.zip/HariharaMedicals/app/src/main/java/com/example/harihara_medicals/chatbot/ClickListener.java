package com.example.harihara_medicals.chatbot;

import android.view.View;

/**
 * Created by NaveenkumarKannan on 06/01/17.
 */

public interface ClickListener {
    void onClick(View view, int position);

    void onLongClick(View view, int position);
}