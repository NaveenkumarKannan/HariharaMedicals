package com.example.harihara_medicals.Model;

public class Notif {

    private String id, notificationtxt, message, success;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNotificationtxt() {
        return notificationtxt;
    }

    public void setNotificationtxt(String notificationtxt) {
        this.notificationtxt = notificationtxt;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }
}
