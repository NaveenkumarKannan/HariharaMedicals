package com.example.harihara_medicals.ui.address;

import androidx.lifecycle.ViewModel;

public class AddressViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
