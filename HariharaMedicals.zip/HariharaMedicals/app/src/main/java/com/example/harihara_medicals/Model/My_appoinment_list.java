package com.example.harihara_medicals.Model;

public class My_appoinment_list {
    private String apid, dr_name,dr_spl,dr_date,dr_time,dr_fees,dr_ex,dr_dept,dr_edu;

    public String getApid() {
        return apid;
    }

    public void setApid(String apid) {
        this.apid = apid;
    }

    public String getDr_name() {
        return dr_name;
    }

    public void setDr_name(String dr_name) {
        this.dr_name = dr_name;
    }

    public String getDr_spl() {
        return dr_spl;
    }

    public void setDr_spl(String dr_spl) {
        this.dr_spl = dr_spl;
    }

    public String getDr_date() {
        return dr_date;
    }

    public void setDr_date(String dr_date) {
        this.dr_date = dr_date;
    }

    public String getDr_time() {
        return dr_time;
    }

    public void setDr_time(String dr_time) {
        this.dr_time = dr_time;
    }

    public String getDr_fees() {
        return dr_fees;
    }

    public void setDr_fees(String dr_fees) {
        this.dr_fees = dr_fees;
    }

    public String getDr_ex() {
        return dr_ex;
    }

    public void setDr_ex(String dr_ex) {
        this.dr_ex = dr_ex;
    }

    public String getDr_dept() {
        return dr_dept;
    }

    public void setDr_dept(String dr_dept) {
        this.dr_dept = dr_dept;
    }

    public String getDr_edu() {
        return dr_edu;
    }

    public void setDr_edu(String dr_edu) {
        this.dr_edu = dr_edu;
    }
}