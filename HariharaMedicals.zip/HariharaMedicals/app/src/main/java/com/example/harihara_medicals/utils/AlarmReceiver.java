package com.example.harihara_medicals.utils;

public class AlarmReceiver {
}
